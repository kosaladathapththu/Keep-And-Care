import { resolve } from 'node:path';
import { startProdServer } from 'vinext/server/prod-server';

const port = Number(process.env.PORT || 3000);
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  throw new Error('The hosting platform provided an invalid PORT.');
}

await startProdServer({
  port,
  host: '0.0.0.0',
  outDir: resolve(process.cwd(), 'dist'),
});
