# cPanel deployment

This version runs as a Node.js application and stores its records in MySQL.

1. In cPanel, create a MySQL database and user, grant the user all privileges on that database, and import `database/schema.mysql.sql`.
2. Create a Node.js application using Node.js 22 or newer. Set the application root to the project directory and the startup file to `app.js`.
3. Configure `DB_HOST`, `DB_PORT`, `DB_NAME`, and `DB_USER` from the database details shown by cPanel. Set `DB_PASSWORD` and a long random `AUTH_SETUP_TOKEN` in the application's environment settings; do not commit real values.
4. Upload the project without `node_modules`, install production dependencies in cPanel, and run `npm run build`.
5. Set the application URL to `knk.supuncompaines.com`, enable HTTPS/AutoSSL, and restart the Node.js application.
6. Point the subdomain's DNS record to the cPanel server as instructed by the hosting provider. DNS and the cPanel virtual host must both be configured for the subdomain.
7. Open `/login` and create the first Developer account with the configured setup token. After setup, remove or rotate the setup token.

From **Settings**, a Developer can download or restore a JSON system backup. The file includes application records, user password hashes, and the audit history; store it securely. Restore replaces current records and signs all users out. Keep independent cPanel/MySQL backups as well.
