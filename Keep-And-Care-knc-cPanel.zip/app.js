'use strict';
module.exports = require('./app.cjs');
